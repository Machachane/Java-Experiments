
package cvideo2b;

public class Kanguru extends Mamifero{
    @Override
    public void locomover(){
        System.out.println("Kanguru Saltando");
    }
    
    
}
