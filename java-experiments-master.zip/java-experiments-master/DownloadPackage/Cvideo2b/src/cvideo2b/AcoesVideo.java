
package cvideo2b;

public interface AcoesVideo {
    public void play();
    public void pause();
    public void like();
}
