
package cvideo2b;

public interface Publicacao {
    
    public abstract void abrir();
    public abstract void fechar();
    public abstract void folhear(int p);
    public abstract void avancaPag();
    public abstract void voltarPag();

    
}
