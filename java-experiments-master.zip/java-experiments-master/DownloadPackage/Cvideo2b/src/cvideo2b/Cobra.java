
package cvideo2b;

public class Cobra extends Reptil{
    
}
