
package cvideo2b;

public class GoldFish extends Peixe{
    
}
