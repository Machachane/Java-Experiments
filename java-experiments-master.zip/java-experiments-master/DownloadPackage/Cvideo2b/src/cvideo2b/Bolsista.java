
package cvideo2b;


public class Bolsista extends Aluno{
    
    private int bolsa;
    
    //-------------------------------------------------- GETTERS AND SETTERS
    
    //-------------------------------------------------- METHODS
    
    public void RenovarBolsa(){
        
    }
    
    @Override
    public void pagarMensalidade(){
        
    }
}
