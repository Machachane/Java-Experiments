
package cvideo2b;

public class Aguia extends Ave{
    
}
